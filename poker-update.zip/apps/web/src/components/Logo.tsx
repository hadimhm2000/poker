/** The spade mark: drawn once, coloured by the theme tokens (see .logo in globals.css). */
export function Logo({ className = "logo" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 32 32" aria-hidden="true" focusable="false">
      <rect width="32" height="32" rx="8" />
      <path d="M16 6.5c-2.2 3-7.2 6.3-7.2 10.2 0 2.5 1.9 4.2 4.1 4.2 1.2 0 2.2-.5 2.9-1.4-.1 1.9-.8 3.5-2.1 4.7h4.6c-1.3-1.2-2-2.8-2.1-4.7.7.9 1.7 1.4 2.9 1.4 2.2 0 4.1-1.7 4.1-4.2C23.2 12.8 18.2 9.5 16 6.5z" />
    </svg>
  );
}
