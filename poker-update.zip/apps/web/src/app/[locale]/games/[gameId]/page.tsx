import { randomUUID } from "node:crypto";
import { type CloseBlocker, closeBlockers, deriveStatus, liveTotals, netResults, settle } from "@poker/domain";
import { gameStory, gameBestHands, latestDraw, listRulings, pendingRequests, schema } from "@poker/db";
import { and, eq, gt, isNull, sql } from "@poker/db";
import { notFound } from "next/navigation";
import { getLocale, getTranslations } from "next-intl/server";
import { addToGameAction, closeGameAction, confirmResultAction, deleteGameAction, removeFromGameAction } from "@/app/actions/homes";
import { recordBestHandAction, deleteBestHandAction } from "@/app/actions/besthands";
import { startDrawAction } from "@/app/actions/ideas";
import { claimPlayerAction, makeJoinLinkAction, requestRebuyAction } from "@/app/actions/live";
import { ErrorNotice } from "@/components/ErrorNotice";
import { PlayerName } from "@/components/PlayerName";
import { Ruling } from "@/components/Ruling";
import { RefereeForm } from "@/components/ideas";
import { ShareCard } from "@/components/ShareCard";
import { AnswerRequest, CopyButton, HostEntryControls, HostQueue, LiveRefresh } from "@/components/live";
import { Link } from "@/i18n/navigation";
import { formatAmount, formatDate, toInputValue } from "@/lib/format";
import { appOrigin, joinToken, qrDataUrl } from "@/lib/live";
import { openPayment } from "@/lib/payment";
import { withUser } from "@/lib/session";

export default async function GamePage({
  params,
  searchParams,
}: {
  params: Promise<{ gameId: string }>;
  searchParams: Promise<{ error?: string; summary?: string; force?: string; delete?: string }>;
}) {
  const { gameId } = await params;
  const { error, summary, force, delete: del } = await searchParams;
  const forceClose = force === "1";
  const deleteConfirm = del === "1";
  if (!/^[0-9a-f-]{36}$/i.test(gameId)) notFound();
  const locale = await getLocale();
  const t = await getTranslations("game");
  const tc = await getTranslations("card");
  const ti = await getTranslations("ideas");
  const tp = await getTranslations("people");
  const tb = await getTranslations("besthand");

  const data = await withUser(async (tx, user) => {
    const [game] = await tx.select().from(schema.games).where(eq(schema.games.id, gameId));
    if (!game) return null;
    const [home] = await tx.select().from(schema.homes).where(eq(schema.homes.id, game.homeId));
    const players = await tx.select().from(schema.players).where(eq(schema.players.homeId, game.homeId));
    const entries = await tx.select().from(schema.gameEntries).where(eq(schema.gameEntries.gameId, gameId));
    const settlements = await tx.select().from(schema.settlements).where(eq(schema.settlements.gameId, gameId));
    const requests = game.status === "live" ? await pendingRequests(tx, game.id) : [];
    const isHost = home!.ownerId === user.id;
    const [invite] =
      isHost && game.status === "live"
        ? await tx
            .select({ id: schema.invites.id })
            .from(schema.invites)
            .where(
              and(
                eq(schema.invites.gameId, game.id),
                isNull(schema.invites.revokedAt),
                gt(schema.invites.expiresAt, sql`now()`),
                sql`${schema.invites.uses} < ${schema.invites.maxUses}`,
              ),
            )
            .limit(1)
        : [];
    const rulings = await listRulings(tx, game.id);
    const draw = await latestDraw(tx, game.id);
    const story = game.status === "closed" ? await gameStory(tx, game.id) : null;
    const bestHands = await gameBestHands(tx, game.id);
    return { game, home: home!, players, entries, settlements, requests, invite, rulings, draw, story, bestHands, userId: user.id };
  });
  if (!data) notFound();
  const { game, home, players, entries, settlements, requests, invite, rulings, draw, story, bestHands, userId } = data;
  const name = new Map(players.map((p) => [p.id, p.displayName]));
  const byId = new Map(players.map((p) => [p.id, p]));
  // Payment details of the payees, decrypted on the server for members of this home only.
  const payInfo = new Map(players.map((p) => [p.id, openPayment(p.paymentInfoEnc)]));
  const moneyHome = { currency: home.currency, unitSuffix: home.unitSuffix, unitDivisor: home.unitDivisor };
  const money = (n: number, signed = false) => formatAmount(n, moneyHome, locale, signed);
  const canWrite = home.ownerId === userId && !home.readOnly && game.status !== "closed";
  // Best hands are the host's to record even after the game is closed (they are not part
  // of the frozen result), so unlike canWrite this does not depend on the game's status.
  const canRecordHand = home.ownerId === userId && !home.readOnly;
  const rules = { requireConfirmation: home.requireConfirmation };
  const domainEntries = entries.map((e) => ({
    playerId: e.playerId,
    totalIn: e.totalIn,
    cashOut: e.cashOut,
    confirmed: !!e.confirmedAt,
    hasAccount: !!byId.get(e.playerId)?.userId,
  }));
  const status = deriveStatus(game.status, domainEntries, rules);
  const totals = liveTotals(domainEntries);
  const blockers = game.status === "closed" ? [] : closeBlockers(domainEntries, rules);
  const inGame = new Set(entries.map((e) => e.playerId));
  const myEntry = entries.find((e) => byId.get(e.playerId)?.userId === userId);
  const isLive = game.status === "live";
  const hasPlayerInHome = players.some((p) => p.userId === userId);
  const claimable = isLive && !canWrite && !hasPlayerInHome ? entries.filter((e) => !byId.get(e.playerId)?.userId) : [];
  const myRequest = myEntry ? requests.find((r) => r.playerId === myEntry.playerId) : undefined;
  const joinUrl = canWrite && invite ? `${await appOrigin()}/${locale}/join/${joinToken(invite.id)}` : null;
  const joinQr = joinUrl ? await qrDataUrl(joinUrl) : null;

  const describe = (b: CloseBlocker) => {
    const names = "playerIds" in b ? new Intl.ListFormat(locale).format(b.playerIds.map((id) => name.get(id) ?? "?")) : "";
    switch (b.code) {
      case "MIN_PLAYERS":
        return t("blocked_MIN_PLAYERS", { min: b.min });
      case "UNBALANCED":
        return t("blocked_UNBALANCED", { difference: money(b.difference, true) });
      default:
        return t(`blocked_${b.code}`, { names });
    }
  };

  // On the force-close summary the preview shows what will really be settled: a player
  // without a cash-out counts as having lost everything (0).
  const forceEntries = forceClose ? domainEntries.map((e) => ({ ...e, cashOut: e.cashOut ?? 0 })) : domainEntries;
  const forceBlockers = forceClose ? closeBlockers(forceEntries, { ...rules, force: true }) : [];
  // The settlement of THIS game only: who won and who lost around tonight's table. Old unpaid
  // debts from earlier games are a separate ledger on the home page, so they never silently
  // change who tonight's losers pay (that mixing is what made the numbers look wrong).
  const transfers =
    game.status === "closed"
      ? settlements.map((s) => ({ from: s.fromPlayer, to: s.toPlayer, amount: s.amount }))
      : blockers.length === 0 || (forceClose && forceBlockers.length === 0)
        ? settle(netResults(forceClose ? forceEntries : domainEntries))
        : [];

  const requestList = requests.length > 0 && (
    <section className="card">
      <h2>{t("requests")}</h2>
      <ul className="plain stack">
        {requests.map((r) => (
          <li key={r.id} className="row" style={{ justifyContent: "space-between" }}>
            <span>{t("requestLine", { name: name.get(r.playerId) ?? "?", amount: money(r.amount) })}</span>
            {canWrite ? <AnswerRequest requestId={r.id} /> : <span className="badge">{t("waitingHost")}</span>}
          </li>
        ))}
      </ul>
    </section>
  );

  const table = (
    <section className="card table-wrap">
      <table>
        <thead>
          <tr>
            <th>{t("player")}</th>
            <th className="end">{t("in")}</th>
            <th className="end">{t("cashOut")}</th>
            <th className="end">{t("net")}</th>
            {canWrite && <th />}
          </tr>
        </thead>
        <tbody>
          {entries.map((e) => {
            const net = e.cashOut === null ? null : e.cashOut - e.totalIn;
            const p = byId.get(e.playerId);
            return (
              <tr key={e.playerId} className={p?.userId === userId ? "me" : undefined}>
                <td>
                  <PlayerName name={name.get(e.playerId) ?? "?"} avatar={p?.avatar} /> {e.confirmedAt && <span className="badge">{t("confirmed")}</span>}
                </td>
                <td className="end num">{money(e.totalIn)}</td>
                <td className="end">
                  {canWrite ? (
                    <HostEntryControls playerId={e.playerId} defaultBuyIn={game.defaultBuyIn} cashOut={e.cashOut} home={moneyHome} />
                  ) : (
                    <span className="num">{e.cashOut === null ? "—" : money(e.cashOut)}</span>
                  )}
                </td>
                <td className={`end num ${net === null ? "" : net > 0 ? "win" : net < 0 ? "loss" : ""}`}>
                  {net === null ? "—" : money(net, true)}
                </td>
                {canWrite && (
                  <td className="end">
                    {e.totalIn === 0 && (
                      <form action={removeFromGameAction}>
                        <input type="hidden" name="gameId" value={game.id} />
                        <input type="hidden" name="playerId" value={e.playerId} />
                        <button className="linklike" type="submit" aria-label={tp("remove")}>
                          ×
                        </button>
                      </form>
                    )}
                  </td>
                )}
              </tr>
            );
          })}
        </tbody>
      </table>

      {canWrite && players.some((p) => !inGame.has(p.id) && !p.mergedInto) && (
        <form action={addToGameAction} className="row" style={{ marginBlockStart: 12 }}>
          <input type="hidden" name="gameId" value={game.id} />
          <select name="playerId" style={{ width: "auto" }} aria-label={t("player")} required>
            {players
              .filter((p) => !inGame.has(p.id) && !p.mergedInto)
              .map((p) => (
                <option key={p.id} value={p.id}>
                  {p.displayName}
                </option>
              ))}
          </select>
          <button className="btn secondary" type="submit">
            {t("addToGame")} ({money(game.defaultBuyIn)})
          </button>
        </form>
      )}
    </section>
  );

  return (
    <>
      <p className="small">
        <Link href={`/homes/${home.id}`}>← {home.name}</Link>
      </p>
      <h1>
        {game.number ? t("title", { number: new Intl.NumberFormat(locale).format(game.number) }) : t("untitled")}{" "}
        <span className={`badge ${game.status === "closed" ? "closed" : "live"}`}>{t(`status_${status}`)}</span>
      </h1>
      {isLive && <LiveRefresh gameId={game.id} />}
      <ErrorNotice code={error} />
      {game.status === "closed" && (
        <div className="alert">
          {t("frozen")} {game.closedAt && t("closedAt", { date: formatDate(game.closedAt, locale, true) })}
        </div>
      )}

      <div className="stats" style={{ marginBlockEnd: 16 }}>
        <div className="stat">
          <div className="label">{t("pot")}</div>
          <div className="value num">{money(totals.pot)}</div>
        </div>
        <div className="stat">
          <div className="label">{t("cashedOut")}</div>
          <div className="value num">{money(totals.cashedOut)}</div>
        </div>
        <div className="stat">
          <div className="label">{t("difference")}</div>
          <div className={`value num ${totals.difference === 0 ? "" : "loss"}`}>{money(totals.difference, true)}</div>
        </div>
      </div>

      {canWrite ? (
        <HostQueue gameId={game.id}>
          {requestList}
          {table}
        </HostQueue>
      ) : (
        <>
          {requestList}
          {table}
        </>
      )}

      {claimable.length > 0 && (
        <section className="card stack">
          <h2>{t("whoAreYou")}</h2>
          <p className="small muted">{t("whoAreYouHint")}</p>
          <div className="row">
            {claimable.map((e) => (
              <form key={e.playerId} action={claimPlayerAction}>
                <input type="hidden" name="gameId" value={game.id} />
                <input type="hidden" name="playerId" value={e.playerId} />
                <button className="btn secondary" type="submit">
                  {t("thisIsMe", { name: name.get(e.playerId) ?? "?" })}
                </button>
              </form>
            ))}
          </div>
        </section>
      )}

      {isLive && myEntry && !canWrite && (
        <section className="card stack">
          {myRequest ? (
            <span className="badge">{t("requestSent", { amount: money(myRequest.amount) })}</span>
          ) : (
            <form action={requestRebuyAction} className="row" style={{ flexWrap: "nowrap", gap: 8 }}>
              <input type="hidden" name="gameId" value={game.id} />
              <input
                name="amount"
                inputMode="decimal"
                dir="ltr"
                style={{ maxWidth: 110 }}
                placeholder={game.defaultBuyIn > 0 ? toInputValue(game.defaultBuyIn, home.unitDivisor) : t("rebuyAmount")}
                aria-label={t("rebuyAmount")}
                required={game.defaultBuyIn <= 0}
              />
              <button className="btn" type="submit">
                {t("askRebuy")}
              </button>
              {game.defaultBuyIn > 0 && <span className="small muted">{t("askRebuyDefault", { amount: money(game.defaultBuyIn) })}</span>}
            </form>
          )}
        </section>
      )}

      {game.status !== "closed" && myEntry && !myEntry.confirmedAt && myEntry.cashOut !== null && (
        <form action={confirmResultAction} style={{ marginBlockEnd: 16 }}>
          <input type="hidden" name="gameId" value={game.id} />
          <button className="btn secondary" type="submit">
            {t("confirmMine")}
          </button>
        </form>
      )}

      {canWrite && isLive && (
        <section className="card" id="join">
          <h2>{t("joinQr")}</h2>
          {joinUrl && joinQr ? (
            <div className="stack" style={{ alignItems: "center", marginBlockStart: 12 }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={joinQr} width={260} height={260} alt={t("joinQrAlt")} />
              <p className="small muted">{t("joinQrHint")}</p>
              <p className="mono small" dir="ltr" style={{ overflowWrap: "anywhere" }}>
                {joinUrl}
              </p>
              <CopyButton text={joinUrl} label={t("copyLink")} done={t("copied")} />
            </div>
          ) : (
            <form action={makeJoinLinkAction} style={{ marginBlockStart: 12 }}>
              <input type="hidden" name="gameId" value={game.id} />
              <button className="btn secondary" type="submit">
                {t("makeJoinQr")}
              </button>
            </form>
          )}
        </section>
      )}

      {(rulings.length > 0 || (isLive && (canWrite || myEntry))) && (
        <section className="card stack" id="referee">
          <h2>{ti("refereeTitle")}</h2>
          {isLive && (canWrite || myEntry) && (
            <details open={rulings.length === 0}>
              <summary>{ti("refereeIntro")}</summary>
              <div style={{ marginBlockStart: 12 }}>
                <RefereeForm gameId={game.id} names={entries.map((e) => name.get(e.playerId) ?? "").filter(Boolean)} />
              </div>
            </details>
          )}
          {rulings.length === 0 ? (
            <p className="muted small">{ti("refereeEmpty")}</p>
          ) : (
            <>
              <h3 style={{ margin: 0 }}>{ti("refereeLog")}</h3>
              {rulings.map((r) => (
                <Ruling key={r.id} r={r} />
              ))}
            </>
          )}
        </section>
      )}

      {(draw || (canWrite && isLive)) && (
        <section className="card stack" id="draw">
          <h2>{ti("drawTitle")}</h2>
          {draw ? (
            <p>
              {draw.check
                ? ti("drawDealer", { name: draw.names.get(draw.check.result.order[0]!) ?? "?" })
                : ti("drawOpen", { count: draw.contributions.length, total: draw.draw.players.length })}{" "}
              <Link href={`/draws/${draw.draw.id}`}>{ti("drawViewLink")}</Link>
            </p>
          ) : (
            <p className="small muted">{ti("drawIntro")}</p>
          )}
          {canWrite && isLive && (!draw || draw.check) && (
            <form action={startDrawAction}>
              <input type="hidden" name="gameId" value={game.id} />
              <button className="btn secondary" type="submit" disabled={entries.length < 2}>
                {ti("drawStart")}
              </button>
            </form>
          )}
        </section>
      )}

      {(game.status === "closed" || summary || blockers.length === 0) && (
        <section className="card table-wrap">
          <h2>{t("settlement")}</h2>
          <p className="small muted">{t("settleGameOnly")}</p>
          {transfers.length === 0 ? (
            <p className="muted">{t("nothingToSettle")}</p>
          ) : (
            <table>
              <tbody>
                {transfers.map((tr, i) => {
                  const info = payInfo.get(tr.to);
                  return (
                    <tr key={i}>
                      <td>{t("pays", { from: name.get(tr.from) ?? "?", to: name.get(tr.to) ?? "?" })}</td>
                      <td className="end num">{money(tr.amount)}</td>
                      <td className="end">
                        {info ? (
                          <span className="pay-info">
                            <span className="mono small" dir="ltr">
                              {info}
                            </span>
                            <CopyButton text={info} label={tp("copy")} done={tp("copied")} />
                          </span>
                        ) : (
                          <span className="muted small">{tp("noPaymentInfo")}</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </section>
      )}

      {(bestHands.length > 0 || canRecordHand) && (
        <section className="card table-wrap" id="besthand">
          <h2>{tb("title")}</h2>
          <p className="small muted">{tb("gameHint")}</p>
          {bestHands.length > 0 && (
            <table>
              <thead>
                <tr>
                  <th>{t("player")}</th>
                  <th>{tb("hand")}</th>
                  <th className="end">{tb("times")}</th>
                  {canRecordHand && <th />}
                </tr>
              </thead>
              <tbody>
                {bestHands.map((b) => (
                  <tr key={b.id}>
                    <td>
                      <PlayerName name={b.name} avatar={byId.get(b.playerId)?.avatar} />
                    </td>
                    <td>{tb(b.hand)}</td>
                    <td className="end num">{tb("timesValue", { count: new Intl.NumberFormat(locale).format(b.times) })}</td>
                    {canRecordHand && (
                      <td className="end">
                        <form action={deleteBestHandAction}>
                          <input type="hidden" name="id" value={b.id} />
                          <input type="hidden" name="gameId" value={game.id} />
                          <input type="hidden" name="homeId" value={home.id} />
                          <input type="hidden" name="from" value="game" />
                          <button className="linklike" type="submit" aria-label={tb("remove")}>
                            ×
                          </button>
                        </form>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {bestHands.length === 0 && <p className="muted">{tb("empty")}</p>}
          {canRecordHand && (
            <form action={recordBestHandAction} className="row" style={{ marginBlockStart: 12, flexWrap: "wrap", gap: 8 }}>
              <input type="hidden" name="gameId" value={game.id} />
              <input type="hidden" name="homeId" value={home.id} />
              <input type="hidden" name="from" value="game" />
              <select name="playerId" required aria-label={t("player")}>
                {[...players]
                  .filter((p) => !p.mergedInto)
                  .sort((a, b) => a.displayName.localeCompare(b.displayName))
                  .map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.displayName}
                    </option>
                  ))}
              </select>
              <select name="hand" required aria-label={tb("hand")}>
                <option value="royal_flush">{tb("royal_flush")}</option>
                <option value="straight_flush">{tb("straight_flush")}</option>
                <option value="four_of_a_kind">{tb("four_of_a_kind")}</option>
              </select>
              <label className="row" style={{ alignItems: "center", gap: 6 }}>
                {tb("times")}
                <input name="times" type="number" min={1} max={99} step={1} defaultValue={1} required style={{ width: 84 }} dir="ltr" />
              </label>
              <button className="btn secondary" type="submit">
                {tb("record")}
              </button>
              <span className="small muted">{tb("hostHint")}</span>
            </form>
          )}
        </section>
      )}

      {canWrite && (
        <section className="card stack">
          {forceClose && summary ? (
            <>
              <h2>{t("forceClose")}</h2>
              <div className="alert">
                <strong>{t("forceCloseWarn")}</strong>
              </div>
              <ul className="plain stack small muted" style={{ paddingInlineStart: 18, margin: 0 }}>
                <li>{t("forceCloseRule1")}</li>
                <li>{t("forceCloseRule2")}</li>
                <li>{t("forceCloseRule3")}</li>
              </ul>
              {forceBlockers.some((b) => b.code === "UNBALANCED") && (
                <ul className="alert" style={{ paddingInlineStart: 28 }}>
                  <li>{describe(forceBlockers.find((b) => b.code === "UNBALANCED")!)}</li>
                </ul>
              )}
              <form action={closeGameAction} className="row">
                <input type="hidden" name="gameId" value={game.id} />
                <input type="hidden" name="closeKey" value={randomUUID()} />
                <input type="hidden" name="version" value={game.version} />
                <input type="hidden" name="force" value="1" />
                <button className="btn danger" type="submit">
                  {t("confirmForceClose")}
                </button>
                <Link className="btn secondary" href={`/games/${game.id}`}>
                  {t("cancel")}
                </Link>
              </form>
            </>
          ) : blockers.length > 0 ? (
            <>
              <ul className="alert" style={{ paddingInlineStart: 28 }}>
                {blockers.map((b) => (
                  <li key={b.code}>{describe(b)}</li>
                ))}
              </ul>
              <details style={{ marginBlockStart: 8 }}>
                <summary>{t("forceClose")}</summary>
                <p className="small muted" style={{ marginBlockStart: 8 }}>
                  {t("forceCloseHint")}
                </p>
                <Link className="btn secondary" href={`/games/${game.id}?summary=1&force=1`}>
                  {t("forceCloseGo")}
                </Link>
              </details>
            </>
          ) : summary ? (
            <>
              <h2>{t("summary")}</h2>
              <div className="alert">{t("warning")}</div>
              <form action={closeGameAction} className="row">
                <input type="hidden" name="gameId" value={game.id} />
                <input type="hidden" name="closeKey" value={randomUUID()} />
                <input type="hidden" name="version" value={game.version} />
                <button className="btn danger" type="submit">
                  {t("confirmClose")}
                </button>
                <Link className="btn secondary" href={`/games/${game.id}`}>
                  {t("cancel")}
                </Link>
              </form>
            </>
          ) : (
            <Link className="btn" href={`/games/${game.id}?summary=1`}>
              {t("close")}
            </Link>
          )}
        </section>
      )}

      {canWrite && (
        <section className="card" id="delete">
          {deleteConfirm ? (
            <>
              <h2>{t("deleteGame")}</h2>
              <div className="alert">
                <strong>{t("deleteWarn")}</strong>
              </div>
              <form action={deleteGameAction} className="row">
                <input type="hidden" name="gameId" value={game.id} />
                <button className="btn danger" type="submit">
                  {t("deleteConfirm")}
                </button>
                <Link className="btn secondary" href={`/games/${game.id}`}>
                  {t("cancel")}
                </Link>
              </form>
            </>
          ) : (
            <details>
              <summary>{t("deleteGame")}</summary>
              <p className="small muted" style={{ marginBlockStart: 8 }}>
                {t("deleteHint")}
              </p>
              <Link className="btn small danger" href={`/games/${game.id}?delete=1`}>
                {t("deleteGo")}
              </Link>
            </details>
          )}
        </section>
      )}

      {story && (
        <section className="card stack" id="story">
          <h2>{ti("storyTitle")}</h2>
          <p className="house-rules">{story.body}</p>
          <p className="small muted">{ti("storyNote")}</p>
        </section>
      )}

      {game.status === "closed" && game.hash && (
        <section className="card stack" id="card">
          <h2>{tc("heading")}</h2>
          <p className="small muted">{tc("intro")}</p>
          {/* eslint-disable-next-line @next/next/no-img-element -- a private PNG from our own route */}
          <img className="result-card-img" src={`/api/games/${game.id}/card?locale=${locale}`} alt={tc("heading")} width={1080} height={1350} />
          <div className="row">
            <ShareCard src={`/api/games/${game.id}/card?f=story&locale=${locale}`} label={tc("share")} filename={`poker-home-${game.number}.png`} />
            <a className="btn small secondary" href={`/api/games/${game.id}/card?download&locale=${locale}`}>
              {tc("post")}
            </a>
            <a className="btn small secondary" href={`/api/games/${game.id}/card?f=story&download&locale=${locale}`}>
              {tc("story")}
            </a>
            <Link className="btn small secondary" href={`/verify/${game.hash}`}>
              {tc("verifyLink")}
            </Link>
          </div>
          <p className="small muted">
            {t("fingerprint")}: <span className="mono">{game.hash}</span>
          </p>
        </section>
      )}
    </>
  );
}
