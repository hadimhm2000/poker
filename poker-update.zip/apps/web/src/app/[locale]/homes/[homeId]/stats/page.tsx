import { bestHandTotals, goodPayerIndex, homeBestHands, homePlan, listSeasons, seasonPeriod } from "@poker/db";
import { badges, formatMoney, homeStats, rowsInPeriod } from "@poker/domain";
import { notFound } from "next/navigation";
import { getLocale, getTranslations } from "next-intl/server";
import { createSeasonAction, deleteSeasonAction } from "@/app/actions/seasons";
import { ErrorNotice } from "@/components/ErrorNotice";
import { PrintButton } from "@/components/PrintButton";
import { DivergingBars, LineChart } from "@/components/charts";
import { Link } from "@/i18n/navigation";
import { formatAmount, formatDate } from "@/lib/format";
import { loadHomeResults, playerSlots } from "@/lib/home";
import { pdfEnabled } from "@/lib/pdf";
import { withUser } from "@/lib/session";

const MAX_LINES = 8;

export default async function StatsPage({
  params,
  searchParams,
}: {
  params: Promise<{ homeId: string }>;
  searchParams: Promise<{ season?: string; error?: string }>;
}) {
  const { homeId } = await params;
  const { season: seasonId, error } = await searchParams;
  const locale = await getLocale();
  const t = await getTranslations("stats");
  const tse = await getTranslations("seasons");
  const tb = await getTranslations("badges");
  const ti = await getTranslations("ideas");
  const th = await getTranslations("besthand");
  const data = await withUser(async (tx, user) => {
    const loaded = await loadHomeResults(tx, homeId);
    return (
      loaded && {
        ...loaded,
        plan: await homePlan(tx, homeId),
        seasons: await listSeasons(tx, homeId),
        payers: await goodPayerIndex(tx, homeId),
        bestHands: await homeBestHands(tx, homeId),
        canWrite: loaded.home.ownerId === user.id && !loaded.home.readOnly,
      }
    );
  });
  if (!data) notFound();
  const { home, seasons } = data;
  const season = seasons.find((x) => x.id === seasonId) ?? null;
  const rows = season ? rowsInPeriod(data.rows, seasonPeriod(season)) : data.rows;
  // The "games" KPI counts every closed game of the home (a game force-closed with no
  // players still has a number), so it always agrees with the numbers in the history.
  // Inside a season the count comes from that season's own games.
  const seasonGames = season ? new Set(rows.map((r) => r.gameId)).size : undefined;
  const s = homeStats(rows, { gamesCount: season ? seasonGames : data.gamesCount });
  const earned = badges(rows);
  const day = (d: string) => formatDate(new Date(`${d}T12:00:00Z`), locale);
  const money = (n: number, signed = false) => formatAmount(n, home, locale, signed);
  // Table cells show bare digits (one unit note per table) as an isolated left-to-right run,
  // so sign, digits and currency words never reorder inside a right-to-left row.
  const unit = home.unitSuffix || (home.currency ? (new Intl.DisplayNames(locale, { type: "currency" }).of(home.currency) ?? home.currency) : "");
  const plain = (n: number, signed = false) =>
    formatMoney(n, { locale, currency: null, divisor: home.unitDivisor, signed });
  const mv = (n: number, signed = false) => <span className="n">{plain(n, signed)}</span>;
  const num = (n: number) => new Intl.NumberFormat(locale).format(n);
  const pct = (n: number) => new Intl.NumberFormat(locale, { style: "percent", maximumFractionDigits: 0 }).format(n);
  const slots = playerSlots(rows);
  // Best hands are the home's own totals: not filtered by season (they are the home's
  // all-time record, like the Excel sheet's best-hand page).
  const handTotals = bestHandTotals(data.bestHands);

  // Lines for the most regular players (fixed colour per player); everyone is in the table.
  const regulars = [...s.leaderboard].sort((a, b) => b.games - a.games).slice(0, MAX_LINES).map((p) => p.playerId);
  const gameIndex = new Map(s.games.map((g, i) => [g.number, i]));
  const series = s.cumulative
    .filter((c) => regulars.includes(c.playerId))
    .map((c) => ({
      key: c.playerId,
      name: c.name,
      slot: slots.get(c.playerId)!,
      points: c.points.map((p) => ({ x: gameIndex.get(p.number)!, y: p.total, label: `#${num(p.number)}` })),
    }));
  const r = s.records;

  return (
    <>
      <p className="small no-print">
        <Link href={`/homes/${home.id}`}>← {home.name}</Link>
      </p>
      <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
        <h1 style={{ margin: 0 }}>
          {t("title")} · {home.name}
          {season && ` · ${season.name}`}
        </h1>
        <div className="row no-print" style={{ alignItems: "center" }}>
          {data.plan === "pro" ? (
            <>
              <a className="btn secondary small" href={`/api/homes/${home.id}/export?format=xlsx&locale=${locale}`}>
                {t("exportXlsx")}
              </a>
              <a className="btn secondary small" href={`/api/homes/${home.id}/export?format=csv&locale=${locale}`}>
                {t("exportCsv")}
              </a>
              {pdfEnabled() && (
                <a className="btn secondary small" href={`/api/homes/${home.id}/pdf?locale=${locale}`}>
                  {t("exportPdf")}
                </a>
              )}
            </>
          ) : (
            <span className="small muted">
              {t("exportXlsx")} · {t("exportCsv")}: <Link href="/pricing">{t("proOnly")}</Link>
            </span>
          )}
          <PrintButton label={t("print")} />
        </div>
      </div>

      <ErrorNotice code={error} />
      <section className="card stack no-print" style={{ marginBlockStart: 16 }}>
        <h2>{tse("title")}</h2>
        <nav className="seasons" aria-label={tse("title")}>
          <Link href={`/homes/${home.id}/stats`} className={season ? "" : "current"}>
            {tse("allTime")}
          </Link>
          {seasons.map((x) => (
            <Link key={x.id} href={`/homes/${home.id}/stats?season=${x.id}`} className={x.id === season?.id ? "current" : ""}>
              {x.name}
              {!x.endsOn && <span className="badge live">{tse("running")}</span>}
            </Link>
          ))}
        </nav>
        {season && (
          <p className="small muted">
            {season.endsOn
              ? tse("range", { start: day(season.startsOn), end: day(season.endsOn) })
              : tse("rangeOpen", { start: day(season.startsOn) })}
          </p>
        )}
        <p className="small muted">{tse("intro")}</p>
        {data.canWrite && (
          <details>
            <summary>{tse("create")}</summary>
            <form action={createSeasonAction} className="row" style={{ marginBlockStart: 8 }}>
              <input type="hidden" name="homeId" value={home.id} />
              <label>
                {tse("name")}
                <input name="name" required maxLength={60} />
              </label>
              <label>
                {tse("startsOn")}
                <input name="startsOn" type="date" required />
              </label>
              <label>
                {tse("endsOn")}
                <input name="endsOn" type="date" />
              </label>
              <button className="btn secondary" type="submit">
                {tse("create")}
              </button>
            </form>
            <form action={createSeasonAction} style={{ marginBlockStart: 8 }}>
              <input type="hidden" name="homeId" value={home.id} />
              <input type="hidden" name="preset" value="month" />
              <button className="btn small secondary" type="submit">
                {tse("thisMonth")}
              </button>
            </form>
          </details>
        )}
        {data.canWrite && season && (
          <form action={deleteSeasonAction}>
            <input type="hidden" name="homeId" value={home.id} />
            <input type="hidden" name="seasonId" value={season.id} />
            <button className="btn small danger" type="submit">
              {tse("delete")}: {season.name}
            </button>
          </form>
        )}
      </section>

      {s.totals.games === 0 ? (
        <p className="muted">{season ? tse("empty") : t("empty")}</p>
      ) : (
        <>
          <div className="stats" style={{ marginBlock: 16 }}>
            {(
              [
                ["games", num(s.totals.games), num(s.totals.games).length],
                ["players", num(s.totals.players), num(s.totals.players).length],
                ["moneyIn", mv(s.totals.moneyIn), plain(s.totals.moneyIn).length],
                ["biggestPot", mv(s.totals.biggestPot), plain(s.totals.biggestPot).length],
                ["averagePot", mv(s.totals.averagePot), plain(s.totals.averagePot).length],
              ] as const
            ).map(([k, v, len]) => (
              <div className="stat" key={k}>
                <div className="label">{t(k)}</div>
                {/* Long amounts step the font down so they stay inside their own box. */}
                <div className="value num" style={len > 12 ? { fontSize: "0.95rem" } : len > 9 ? { fontSize: "1.1rem" } : undefined}>
                  {v}
                </div>
                {unit && (k === "moneyIn" || k === "biggestPot" || k === "averagePot") && <div className="unit">{unit}</div>}
              </div>
            ))}
          </div>

          <section className="card table-wrap">
            <h2>{season ? t("seasonLeaderboard", { season: season.name }) : t("leaderboard")}</h2>
            {unit && <p className="small muted unit-note">{t("unitNote", { unit })}</p>}
            <table className="data">
              <thead>
                <tr>
                  <th className="end">{t("rank")}</th>
                  <th>{t("player")}</th>
                  <th className="end">{t("played")}</th>
                  <th className="end">{t("wins")}</th>
                  <th className="end fold-sm">{t("winRate")}</th>
                  <th className="end">{t("net")}</th>
                  <th className="end fold-sm">{t("average")}</th>
                  <th className="end fold-sm">{t("best")}</th>
                  <th className="end fold-sm">{t("worst")}</th>
                </tr>
              </thead>
              <tbody>
                {s.leaderboard.map((p, i) => (
                  <tr key={p.playerId}>
                    {/* The rank of every player (not just medals), like the Excel sheet's # column. */}
                    <td className={`end num rank${p.medal ? ` medal-${p.medal}` : ""}`}>
                      {num(i + 1)}
                    </td>
                    <td>
                      <Link href={`/homes/${home.id}/players/${p.playerId}`}>{p.name}</Link>
                    </td>
                    <td className="end num">{num(p.games)}</td>
                    <td className="end num">{num(p.wins)}</td>
                    <td className="end num fold-sm">{pct(p.winRate)}</td>
                    <td className={`end num ${p.net > 0 ? "win" : p.net < 0 ? "loss" : ""}`}>
                      <strong>{mv(p.net, true)}</strong>
                    </td>
                    <td className="end num fold-sm">{mv(p.average, true)}</td>
                    <td className="end num fold-sm">{mv(p.best, true)}</td>
                    <td className="end num fold-sm">{mv(p.worst, true)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>

          <section className="card">
            <h2>{tb("title")}</h2>
            {earned.length === 0 ? (
              <p className="muted small">{tb("none")}</p>
            ) : (
              <div className="badges">
                {earned.map((b) => (
                  <div className="badge-card" key={`${b.kind}-${b.playerId}`}>
                    <strong>{tb(b.kind)}</strong>
                    <span>
                      <Link href={`/homes/${home.id}/players/${b.playerId}`}>{b.name}</Link>
                    </span>
                    <span className="small muted">
                      {b.kind === "bigWin"
                        ? tb("bigWinBody", { amount: money(b.value, true), number: num(b.gameNumber!) })
                        : b.kind === "comeback"
                          ? tb("comebackBody", { amount: money(b.value) })
                          : tb(`${b.kind}Body`, { count: num(b.value) })}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </section>

          {data.payers && data.payers.length > 0 && (
            <section className="card table-wrap" id="payers">
              <h2>{ti("payerTitle")}</h2>
              <p className="small muted">{ti("payerIntro")}</p>
              <table>
                <thead>
                  <tr>
                    <th>{t("player")}</th>
                    <th className="end">{ti("payerDays")}</th>
                    <th className="end">{ti("payerDebts")}</th>
                    <th className="end">{ti("payerOpen")}</th>
                  </tr>
                </thead>
                <tbody>
                  {data.payers.map((p) => (
                    <tr key={p.playerId}>
                      <td>{p.name}</td>
                      <td className="end num">
                        {p.averageDays === null
                          ? "—"
                          : ti("payerDaysValue", { days: new Intl.NumberFormat(locale, { maximumFractionDigits: 1 }).format(p.averageDays) })}
                      </td>
                      <td className="end num">{num(p.debts)}</td>
                      <td className="end num">{num(p.open)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>
          )}

          <div>
            <section className="card keep">
              <h2>{t("cumulative")}</h2>
              <p className="small muted">{t("cumulativeNote", { count: num(series.length) })}</p>
              <LineChart
                title={t("cumulative")}
                series={series}
                xLabels={s.games.map((g) => `#${num(g.number)}`)}
                format={(v) => plain(v, true)}
              />
            </section>
            <section className="card keep">
              <h2>{t("netChart")}</h2>
              <DivergingBars
                title={t("netChart")}
                rows={s.leaderboard.map((p) => ({ key: p.playerId, name: p.name, value: p.net }))}
                format={(v) => plain(v, true)}
              />
            </section>
          </div>

                    <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(340px, 1fr))" }}>
            <section className="card table-wrap">
              <h2>{t("lastGames", { count: num(s.lastGames.length) })}</h2>
              {unit && <p className="small muted unit-note">{t("unitNote", { unit })}</p>}
              <table className="data">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>{t("date")}</th>
                    <th className="end">{t("pot")}</th>
                    <th>{t("topWinner")}</th>
                    <th>{t("topLoser")}</th>
                  </tr>
                </thead>
                <tbody>
                  {s.lastGames.map((g) => (
                    <tr key={g.gameId}>
                      <td>
                        <Link href={`/games/${g.gameId}`}>{num(g.number)}</Link>
                      </td>
                      <td className="small">{formatDate(g.closedAt, locale)}</td>
                      <td className="end num">{mv(g.pot)}</td>
                      <td className="small">
                        {g.topWinner && (
                          <>
                            {g.topWinner.name} <span className="win num">{mv(g.topWinner.net, true)}</span>
                          </>
                        )}
                      </td>
                      <td className="small">
                        {g.topLoser && (
                          <>
                            {g.topLoser.name} <span className="loss num">{mv(g.topLoser.net, true)}</span>
                          </>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>

            <section className="card table-wrap">
              <h2>{t("records")}</h2>
              <table>
                <tbody>
                  {r.biggestWin && (
                    <tr>
                      <td>{t("biggestWin")}</td>
                      <td>{r.biggestWin.name}</td>
                      <td className="end num win">{mv(r.biggestWin.value, true)}</td>
                      <td className="small muted">{t("inGame", { number: num(r.biggestWin.gameNumber!) })}</td>
                    </tr>
                  )}
                  {r.biggestLoss && (
                    <tr>
                      <td>{t("biggestLoss")}</td>
                      <td>{r.biggestLoss.name}</td>
                      <td className="end num loss">{mv(r.biggestLoss.value, true)}</td>
                      <td className="small muted">{t("inGame", { number: num(r.biggestLoss.gameNumber!) })}</td>
                    </tr>
                  )}
                  {r.longestWinStreak && (
                    <tr>
                      <td>{t("longestWinStreak")}</td>
                      <td>{r.longestWinStreak.name}</td>
                      <td className="end" colSpan={2}>
                        {t("streakValue", { count: num(r.longestWinStreak.value) })}
                      </td>
                    </tr>
                  )}
                  {r.longestLossStreak && (
                    <tr>
                      <td>{t("longestLossStreak")}</td>
                      <td>{r.longestLossStreak.name}</td>
                      <td className="end" colSpan={2}>
                        {t("streakValue", { count: num(r.longestLossStreak.value) })}
                      </td>
                    </tr>
                  )}
                  {r.mostGames && (
                    <tr>
                      <td>{t("mostGames")}</td>
                      <td>{r.mostGames.name}</td>
                      <td className="end num" colSpan={2}>
                        {num(r.mostGames.value)}
                      </td>
                    </tr>
                  )}
                  {r.bestAverage && (
                    <tr>
                      <td>{t("bestAverage")}</td>
                      <td>{r.bestAverage.name}</td>
                      <td className="end num" colSpan={2}>
                        {mv(r.bestAverage.value, true)}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </section>
          </div>
        </>
      )}

          {data.bestHands.length > 0 && (
            <section className="card table-wrap" id="besthand">
              <h2>{th("title")}</h2>
              <p className="small muted">{th("homeHint")}</p>
              <table className="data">
                <thead>
                  <tr>
                    <th>{t("player")}</th>
                    <th className="end">{th("royal_flush")}</th>
                    <th className="end">{th("straight_flush")}</th>
                    <th className="end">{th("four_of_a_kind")}</th>
                    <th className="end">{th("total")}</th>
                  </tr>
                </thead>
                <tbody>
                  {handTotals.players.map((p) => (
                    <tr key={p.playerId}>
                      <td>
                        <Link href={`/homes/${home.id}/players/${p.playerId}`}>{p.name}</Link>
                      </td>
                      <td className="end num">{p.counts.royal_flush ? num(p.counts.royal_flush) : "—"}</td>
                      <td className="end num">{p.counts.straight_flush ? num(p.counts.straight_flush) : "—"}</td>
                      <td className="end num">{p.counts.four_of_a_kind ? num(p.counts.four_of_a_kind) : "—"}</td>
                      <td className="end num">
                        <strong>{num(p.total)}</strong>
                      </td>
                    </tr>
                  ))}
                  <tr>
                    <td>
                      <strong>{th("totalRow")}</strong>
                    </td>
                    <td className="end num">
                      <strong>{num(handTotals.byHand.royal_flush)}</strong>
                    </td>
                    <td className="end num">
                      <strong>{num(handTotals.byHand.straight_flush)}</strong>
                    </td>
                    <td className="end num">
                      <strong>{num(handTotals.byHand.four_of_a_kind)}</strong>
                    </td>
                    <td className="end num">
                      <strong>{num(handTotals.total)}</strong>
                    </td>
                  </tr>
                </tbody>
              </table>
            </section>
          )}

    </>
  );
}
