import { AVATARS, activeInvites, bestHandTotals, homeBestHands, homePlan, homeSettings, ledger, listNetting, memberList, nettingCandidates, schema } from "@poker/db";
import { asc, desc, eq, sql } from "@poker/db";
import { notFound } from "next/navigation";
import { getLocale, getTranslations } from "next-intl/server";
import { addPlayerAction, createInviteAction, houseRulesAction, markAllPaidAction, markPaidAction, moneySettingsAction, newGameAction } from "@/app/actions/homes";
import { recordBestHandAction, deleteBestHandAction } from "@/app/actions/besthands";
import { mergePlayersAction, playerProfileAction, removeMemberAction, revokeInviteAction } from "@/app/actions/players";
import { answerNettingAction, cancelNettingAction, homeOptionsAction, proposeNettingAction } from "@/app/actions/ideas";
import { connectGroupAction, disconnectGroupAction } from "@/app/actions/telegram";
import { ErrorNotice } from "@/components/ErrorNotice";
import { PlayerName } from "@/components/PlayerName";
import { CopyButton } from "@/components/live";
import { Link } from "@/i18n/navigation";
import { sha256 } from "@/lib/crypto";
import { formatAmount, formatDate } from "@/lib/format";
import { parseUnitChoice } from "@/lib/money-units";
import { appOrigin, inviteToken, qrDataUrl } from "@/lib/live";
import { openPayment } from "@/lib/payment";
import { pdfEnabled } from "@/lib/pdf";
import { withUser } from "@/lib/session";
import { telegramConfigured } from "@/telegram/instance";

export default async function HomePage({
  params,
  searchParams,
}: {
  params: Promise<{ homeId: string }>;
  searchParams: Promise<{ error?: string }>;
}) {
  const { homeId } = await params;
  const { error } = await searchParams;
  if (!/^[0-9a-f-]{36}$/i.test(homeId)) notFound();
  const locale = await getLocale();
  const t = await getTranslations("homes");
  const tg = await getTranslations("game");
  const ts = await getTranslations("stats");
  const tn = await getTranslations("nights");
  const tt = await getTranslations("telegram");
  const tr = await getTranslations("rules");
  const tp = await getTranslations("people");
  const tb = await getTranslations("billing");
  const ti = await getTranslations("ideas");
  const th = await getTranslations("besthand");

  const data = await withUser(async (tx, user) => {
    const [home] = await tx.select().from(schema.homes).where(eq(schema.homes.id, homeId));
    if (!home) return null;
    const players = await tx.select().from(schema.players).where(eq(schema.players.homeId, homeId)).orderBy(asc(schema.players.displayName));
    const games = await tx.select().from(schema.games).where(eq(schema.games.homeId, homeId)).orderBy(desc(schema.games.createdAt));
    const debts = await ledger(tx, homeId);
    const members = await memberList(tx, homeId);
    const isOwner = home.ownerId === user.id;
    const invites = isOwner ? await activeInvites(tx, homeId) : [];
    // Free plan: 3 games in total across the owner's homes (the trigger enforces it; this
    // only swaps the "New game" form for the upgrade note).
    let atGameLimit = false;
    if (isOwner && (await homePlan(tx, homeId)) === "free") {
      const [c] = await tx
        .select({ n: sql<number>`count(*)::int` })
        .from(schema.games)
        .innerJoin(schema.homes, eq(schema.homes.id, schema.games.homeId))
        .where(eq(schema.homes.ownerId, user.id));
      atGameLimit = (c?.n ?? 0) >= 3;
    }
    // Cross-home netting: only the two people involved ever see these.
    const candidates = (await nettingCandidates(tx, user.id)).filter((c) => c.mine.homeId === homeId || c.theirs.homeId === homeId);
    const proposals = await listNetting(tx, { homeId, status: "pending" });
    const bestHands = await homeBestHands(tx, homeId);
    return { home, players, games, debts, members, invites, candidates, proposals, bestHands, isOwner, userId: user.id, atGameLimit };
  });
  if (!data) notFound();
  const { home, players, games, debts, members, candidates, proposals, bestHands, isOwner, userId, atGameLimit } = data;
  const settings = homeSettings(home.settings);
  const name = new Map(players.map((p) => [p.id, p.displayName]));
  const byId = new Map(players.map((p) => [p.id, p]));
  const active = players.filter((p) => !p.mergedInto);
  // Decrypted on the server, for members of this home only (RLS returned these rows).
  const payment = new Map(players.map((p) => [p.id, openPayment(p.paymentInfoEnc)]));
  const money = (n: number) => formatAmount(n, home, locale);
  const num = (n: number) => new Intl.NumberFormat(locale).format(n);
  const canWrite = isOwner && !home.readOnly;
  // Opens with the home's current unit/scale: recognise "هزار تومان" style suffixes.
  const moneyNow = parseUnitChoice(home.unitSuffix, home.unitDivisor, locale);
  const canEdit = (p: (typeof players)[number]) => canWrite || p.userId === userId;
  // One player's edit form (avatar + payment details), reused by the players list and the
  // payment-cards section so both places stay in step.
  const playerEdit = (p: (typeof players)[number]) => (
    <details className="player-edit">
      <summary>{tp("editPlayer")}</summary>
      <form action={playerProfileAction} className="stack">
        <input type="hidden" name="homeId" value={home.id} />
        <input type="hidden" name="playerId" value={p.id} />
        <fieldset className="avatar-picker">
          <legend>{tp("avatar")}</legend>
          <label>
            <input type="radio" name="avatar" value="" defaultChecked={!p.avatar} />
            <span>{tp("noAvatar")}</span>
          </label>
          {AVATARS.map((a) => (
            <label key={a}>
              <input type="radio" name="avatar" value={a} defaultChecked={p.avatar === a} />
              <span>{a}</span>
            </label>
          ))}
        </fieldset>
        <label>
          {tp("paymentInfo")}
          <textarea name="paymentInfo" rows={2} maxLength={200} dir="auto" defaultValue={payment.get(p.id) ?? ""} />
        </label>
        <p className="small muted">{tp("paymentHint")}</p>
        <div>
          <button className="btn small secondary" type="submit">
            {tp("save")}
          </button>
        </div>
      </form>
    </details>
  );
  const origin = await appOrigin();
  // Links made with the HMAC scheme can be shown again; older random-token links cannot.
  const invites = await Promise.all(
    data.invites.map(async (i) => {
      const token = inviteToken(i.id);
      const url = sha256(token).equals(Buffer.from(i.tokenHash)) ? `${origin}/${locale}/invite/${token}` : null;
      return { ...i, url, qr: url ? await qrDataUrl(url) : null };
    }),
  );
  const storyAvailable = !!process.env.ANTHROPIC_API_KEY;
  // Best hands: the home's own totals (who hit what, how often), newest record first.
  const handTotals = bestHandTotals(bestHands);
  const handNum = (n: number) => new Intl.NumberFormat(locale).format(n);

  return (
    <>
      <h1>{home.name}</h1>
      <ErrorNotice code={error} />
      {home.readOnly && (
        <div className="alert">
          {t("readOnly")} {isOwner && <Link href="/pricing">{tb("upgradeLink")}</Link>}
        </div>
      )}

      <div className="grid">
        <section className="card">
          <h2>{t("games")}</h2>
          {canWrite && atGameLimit && (
            <p className="alert">
              {t("gameLimit")} <Link href="/pricing">{tb("upgradeLink")}</Link>
            </p>
          )}
          {canWrite && !atGameLimit && (
            <form action={newGameAction} className="row" style={{ marginBlockEnd: 12 }}>
              <input type="hidden" name="homeId" value={home.id} />
              <label style={{ flex: 1 }}>
                {t("defaultBuyIn")}
                <input name="defaultBuyIn" inputMode="decimal" required dir="ltr" />
              </label>
              <button className="btn" type="submit">
                {t("newGame")}
              </button>
              <span className="small muted" style={{ alignSelf: "center" }}>
                {t("moneyHint", { amount: money(200 * home.unitDivisor) })}
              </span>
            </form>
          )}
          <ul style={{ paddingInlineStart: 18, margin: 0 }}>
            {games.map((g) => (
              <li key={g.id}>
                <Link href={`/games/${g.id}`}>
                  {g.number ? tg("title", { number: new Intl.NumberFormat(locale).format(g.number) }) : tg("untitled")}
                </Link>{" "}
                <span className={`badge ${g.status}`}>{tg(`status_${g.status}`)}</span>{" "}
                <span className="muted small">{formatDate(g.closedAt ?? g.createdAt, locale)}</span>
              </li>
            ))}
          </ul>
          <p style={{ marginBlockEnd: 0 }}>
            <Link href={`/homes/${home.id}/history`}>{t("history")}</Link> ·{" "}
            <Link href={`/homes/${home.id}/stats`}>{ts("title")}</Link> ·{" "}
            <Link href={`/homes/${home.id}/nights`}>{tn("title")}</Link> ·{" "}
            <Link href={`/rules?home=${home.id}`}>{t("rules")}</Link>
            {canWrite && (
              <>
                {" "}
                · <Link href={`/homes/${home.id}/import`}>{ts("import")}</Link>
              </>
            )}
          </p>
        </section>

        <section className="card" id="players">
          <h2>{t("players")}</h2>
          <ul className="plain player-list">
            {active.map((p) => (
              <li key={p.id}>
                <PlayerName name={p.displayName} avatar={p.avatar} /> {p.userId && <span className="badge">{t("member")}</span>}
                {canEdit(p) && playerEdit(p)}
              </li>
            ))}
          </ul>
          {canWrite && (
            <form action={addPlayerAction} className="row">
              <input type="hidden" name="homeId" value={home.id} />
              <label style={{ flex: 1 }}>
                {t("playerName")}
                <input name="name" required maxLength={40} />
              </label>
              <button className="btn secondary" type="submit">
                {t("addPlayer")}
              </button>
            </form>
          )}
        </section>
      </div>

      <section className="card" id="cards">
        <h2>{tp("cardsTitle")}</h2>
        <p className="small muted">{tp("cardsHint")}</p>
        <ul className="plain stack">
          {active.map((p) => {
            const info = payment.get(p.id);
            return (
              <li key={p.id} className="row" style={{ justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
                <span>
                  <PlayerName name={p.displayName} avatar={p.avatar} /> {p.userId && <span className="badge">{t("member")}</span>}
                </span>
                <span className="row" style={{ flexWrap: "nowrap", alignItems: "center" }}>
                  {info ? (
                    <span className="pay-info">
                      <span className="mono small" dir="ltr">
                        {info}
                      </span>
                      <CopyButton text={info} label={tp("copy")} done={tp("copied")} />
                    </span>
                  ) : (
                    <span className="muted small">{tp("noPaymentInfo")}</span>
                  )}
                </span>
                {canEdit(p) && playerEdit(p)}
              </li>
            );
          })}
        </ul>
      </section>

      <section className="card" id="ledger">
        <div className="row" style={{ justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
          <h2 style={{ margin: 0 }}>{t("ledger")}</h2>
          {debts.length > 0 && (
            <span className="row">
              <Link className="btn small secondary" href={`/homes/${home.id}/debts`}>
                {t("debtsSheet")}
              </Link>
              {pdfEnabled() && isOwner && (
                <a className="btn small secondary" href={`/api/homes/${home.id}/pdf?view=debts&locale=${locale}`}>
                  {t("downloadPdf")}
                </a>
              )}
            </span>
          )}
        </div>
        {debts.length === 0 ? (
          <p className="muted">{t("noDebts")}</p>
        ) : (
          <>
            <p className="small muted">{t("ledgerWhoConfirms")}</p>
            <div className="table-wrap">
              <table>
                <tbody>
                  {debts.map((d) => {
                    const info = payment.get(d.to);
                    // Only the player who owes (with their account linked) or the host may
                    // confirm a payment — nobody else even sees the button.
                    const canConfirm = isOwner || byId.get(d.from)?.userId === userId;
                    return (
                      <tr key={d.settlementId}>
                        <td>
                          {byId.get(d.from)?.avatar && (
                            <span className="avatar" aria-hidden="true">
                              {byId.get(d.from)?.avatar}
                            </span>
                          )}
                          {tg("pays", { from: name.get(d.from) ?? "?", to: name.get(d.to) ?? "?" })}
                        </td>
                        <td className="end num">
                          {money(d.amount)}
                          {d.amount !== d.original && <span className="small muted"> {ti("ofOriginal", { original: money(d.original) })}</span>}
                        </td>
                        <td className="muted small">#{d.gameNumber === null ? "" : new Intl.NumberFormat(locale).format(d.gameNumber)}</td>
                        <td>
                          {info ? (
                            <span className="pay-info">
                              <span className="mono small" dir="ltr">
                                {info}
                              </span>
                              <CopyButton text={info} label={tp("copy")} done={tp("copied")} />
                            </span>
                          ) : (
                            <span className="muted small">{tp("noPaymentInfo")}</span>
                          )}
                        </td>
                        <td className="end">
                          {canConfirm ? (
                            <form action={markPaidAction}>
                              <input type="hidden" name="homeId" value={home.id} />
                              <input type="hidden" name="settlementId" value={d.settlementId} />
                              <button className="btn small secondary" type="submit">
                                {t("markPaid")}
                              </button>
                            </form>
                          ) : (
                            <span className="muted small">{t("waitsForConfirm", { name: name.get(d.from) ?? "?" })}</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
        {canWrite && debts.length > 0 && (
          <form action={markAllPaidAction} className="row" style={{ marginBlockStart: 12, flexWrap: "wrap", gap: 8 }}>
            <input type="hidden" name="homeId" value={home.id} />
            <button className="btn small secondary" type="submit">
              {t("markAllPaid")}
            </button>
            <span className="small muted">{t("markAllPaidHint")}</span>
          </form>
        )}
      </section>

      {(bestHands.length > 0 || canWrite) && (
        <section className="card table-wrap" id="besthand">
          <h2>{th("title")}</h2>
          <p className="small muted">{th("homeHint")}</p>
          {bestHands.length > 0 ? (
            <>
              <table>
                <thead>
                  <tr>
                    <th>{th("game")}</th>
                    <th>{tg("player")}</th>
                    <th>{th("hand")}</th>
                    <th className="end">{th("times")}</th>
                    {canWrite && <th />}
                  </tr>
                </thead>
                <tbody>
                  {[...bestHands].reverse().map((b) => (
                    <tr key={b.id}>
                      <td>
                        <Link href={`/games/${b.gameId}`}>{b.number ? tg("title", { number: handNum(b.number) }) : th("openGame")}</Link>{" "}
                        <span className="muted small">{formatDate(b.at, locale)}</span>
                      </td>
                      <td>
                        <PlayerName name={b.name} avatar={byId.get(b.playerId)?.avatar} />
                      </td>
                      <td>{th(b.hand)}</td>
                      <td className="end num">{th("timesValue", { count: handNum(b.times) })}</td>
                      {canWrite && (
                        <td className="end">
                          <form action={deleteBestHandAction}>
                            <input type="hidden" name="id" value={b.id} />
                            <input type="hidden" name="gameId" value={b.gameId} />
                            <input type="hidden" name="homeId" value={home.id} />
                            <input type="hidden" name="from" value="home" />
                            <button className="linklike" type="submit" aria-label={th("remove")}>
                              ×
                            </button>
                          </form>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
              <table style={{ marginBlockStart: 16 }}>
                <thead>
                  <tr>
                    <th>{tg("player")}</th>
                    <th className="end">{th("royal_flush")}</th>
                    <th className="end">{th("straight_flush")}</th>
                    <th className="end">{th("four_of_a_kind")}</th>
                    <th className="end">{th("total")}</th>
                  </tr>
                </thead>
                <tbody>
                  {handTotals.players.map((p) => (
                    <tr key={p.playerId}>
                      <td>
                        <PlayerName name={p.name} avatar={byId.get(p.playerId)?.avatar} />
                      </td>
                      <td className="end num">{p.counts.royal_flush ? handNum(p.counts.royal_flush) : "—"}</td>
                      <td className="end num">{p.counts.straight_flush ? handNum(p.counts.straight_flush) : "—"}</td>
                      <td className="end num">{p.counts.four_of_a_kind ? handNum(p.counts.four_of_a_kind) : "—"}</td>
                      <td className="end num">
                        <strong>{handNum(p.total)}</strong>
                      </td>
                    </tr>
                  ))}
                  <tr>
                    <td>
                      <strong>{th("totalRow")}</strong>
                    </td>
                    <td className="end num">
                      <strong>{handNum(handTotals.byHand.royal_flush)}</strong>
                    </td>
                    <td className="end num">
                      <strong>{handNum(handTotals.byHand.straight_flush)}</strong>
                    </td>
                    <td className="end num">
                      <strong>{handNum(handTotals.byHand.four_of_a_kind)}</strong>
                    </td>
                    <td className="end num">
                      <strong>{handNum(handTotals.total)}</strong>
                    </td>
                  </tr>
                </tbody>
              </table>
            </>
          ) : (
            <p className="muted">{th("empty")}</p>
          )}
          {canWrite && games.length > 0 && (
            <form action={recordBestHandAction} className="row" style={{ marginBlockStart: 12, flexWrap: "wrap", gap: 8 }}>
              <input type="hidden" name="homeId" value={home.id} />
              <input type="hidden" name="from" value="home" />
              <select name="gameId" required aria-label={th("game")}>
                {games.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.number ? tg("title", { number: handNum(g.number) }) : tg("untitled")} · {formatDate(g.closedAt ?? g.createdAt, locale)}
                  </option>
                ))}
              </select>
              <select name="playerId" required aria-label={tg("player")}>
                {active.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.displayName}
                  </option>
                ))}
              </select>
              <select name="hand" required aria-label={th("hand")}>
                <option value="royal_flush">{th("royal_flush")}</option>
                <option value="straight_flush">{th("straight_flush")}</option>
                <option value="four_of_a_kind">{th("four_of_a_kind")}</option>
              </select>
              <label className="row" style={{ alignItems: "center", gap: 6 }}>
                {th("times")}
                <input name="times" type="number" min={1} max={99} step={1} defaultValue={1} required style={{ width: 84 }} dir="ltr" />
              </label>
              <button className="btn secondary" type="submit">
                {th("record")}
              </button>
              <span className="small muted">{th("hostHint")}</span>
            </form>
          )}
        </section>
      )}

      {(candidates.length > 0 || proposals.length > 0) && (
        <section className="card stack" id="netting">
          <h2>{ti("nettingTitle")}</h2>
          <p className="small muted">{ti("nettingIntro")}</p>
          <ul className="plain stack">
            {proposals.map(({ p, a, b }) => {
              const homes = { homeA: a.homeName ?? "?", homeB: b.homeName ?? "?", amount: money(p.amount) };
              return (
                <li key={p.id} className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
                  {p.responder === userId ? (
                    <>
                      <span>{ti("nettingFromThem", { name: a.from ?? "?", ...homes })}</span>
                      <span className="row">
                        {(["accept", "decline"] as const).map((answer) => (
                          <form key={answer} action={answerNettingAction}>
                            <input type="hidden" name="homeId" value={home.id} />
                            <input type="hidden" name="proposalId" value={p.id} />
                            <input type="hidden" name="answer" value={answer} />
                            <button className={`btn small${answer === "accept" ? "" : " secondary"}`} type="submit">
                              {ti(answer)}
                            </button>
                          </form>
                        ))}
                      </span>
                    </>
                  ) : (
                    <>
                      <span>{ti("nettingFromMe", { name: a.to ?? "?", ...homes })}</span>
                      <form action={cancelNettingAction}>
                        <input type="hidden" name="homeId" value={home.id} />
                        <input type="hidden" name="proposalId" value={p.id} />
                        <button className="btn small secondary" type="submit">
                          {ti("withdraw")}
                        </button>
                      </form>
                    </>
                  )}
                </li>
              );
            })}
            {candidates
              .filter((c) => !proposals.some(({ p }) => [p.proposerDebt, p.responderDebt].includes(c.mine.settlementId) && [p.proposerDebt, p.responderDebt].includes(c.theirs.settlementId)))
              .map((c) => (
                <li key={`${c.mine.settlementId}-${c.theirs.settlementId}`} className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
                  <span>
                    {ti("nettingOffer", {
                      name: c.otherName,
                      mine: money(c.mine.amount),
                      mineHome: c.mine.homeName,
                      theirs: money(c.theirs.amount),
                      theirsHome: c.theirs.homeName,
                      amount: money(c.amount),
                    })}
                  </span>
                  <form action={proposeNettingAction}>
                    <input type="hidden" name="homeId" value={home.id} />
                    <input type="hidden" name="mine" value={c.mine.settlementId} />
                    <input type="hidden" name="theirs" value={c.theirs.settlementId} />
                    <button className="btn small" type="submit">
                      {ti("propose")}
                    </button>
                  </form>
                </li>
              ))}
          </ul>
        </section>
      )}

      <section className="card stack">
        <h2>{tr("houseTitle")}</h2>
        {canWrite ? (
          <form action={houseRulesAction} className="stack">
            <input type="hidden" name="homeId" value={home.id} />
            <label>
              {tr("houseEdit")}
              <textarea name="houseRules" defaultValue={home.houseRules} maxLength={2000} rows={4} />
            </label>
            <p className="small muted">{tr("houseHint")}</p>
            <div>
              <button className="btn secondary" type="submit">
                {tr("houseSave")}
              </button>
            </div>
          </form>
        ) : home.houseRules ? (
          <p className="house-rules">{home.houseRules}</p>
        ) : (
          <p className="muted">{tr("houseNone")}</p>
        )}
      </section>

      {canWrite && (
        <section className="card stack" id="money">
          <h2>{t("moneyTitle")}</h2>
          <p className="small muted">{t("moneyNote")}</p>
          <form action={moneySettingsAction} className="stack">
            <input type="hidden" name="homeId" value={home.id} />
            <label>
              {t("moneyUnit")}
              <select name="unit" defaultValue={moneyNow.unit} style={{ width: "auto" }}>
                <option value="toman">{t("moneyUnitToman")}</option>
                <option value="rial">{t("moneyUnitRial")}</option>
                <option value="usd">{t("moneyUnitUsd")}</option>
                <option value="eur">{t("moneyUnitEur")}</option>
                <option value="custom">{t("moneyUnitCustom")}</option>
              </select>
            </label>
            <label>
              {t("moneyScale")}
              <select name="scale" defaultValue={String(moneyNow.scale)} style={{ width: "auto" }}>
                <option value="1">{t("moneyScaleFull")}</option>
                <option value="1000">{t("moneyScaleThousand")}</option>
                <option value="1000000">{t("moneyScaleMillion")}</option>
              </select>
            </label>
            <label>
              {t("moneyCustomLabel")}
              <input name="customSuffix" maxLength={24} dir="auto" defaultValue={moneyNow.unit === "custom" ? home.unitSuffix : ""} />
            </label>
            <p className="small muted" style={{ margin: 0 }}>
              {t("moneyHint", { amount: money(200 * home.unitDivisor) })}
            </p>
            <div>
              <button className="btn secondary" type="submit">
                {t("moneySave")}
              </button>
            </div>
          </form>
        </section>
      )}

      {canWrite && (
        <section className="card stack" id="options">
          <h2>{ti("optionsTitle")}</h2>
          <form action={homeOptionsAction} className="stack">
            <input type="hidden" name="homeId" value={home.id} />
            <label className="row" style={{ alignItems: "center", gap: 8 }}>
              <input type="checkbox" name="goodPayerIndex" defaultChecked={!!settings.goodPayerIndex} style={{ width: "auto" }} />
              {ti("optionGoodPayer")}
            </label>
            <p className="small muted" style={{ margin: 0 }}>{ti("optionGoodPayerHint")}</p>
            <label className="row" style={{ alignItems: "center", gap: 8 }}>
              <input type="checkbox" name="nightStory" defaultChecked={!!settings.nightStory} style={{ width: "auto" }} />
              {ti("optionStory")}
            </label>
            <p className="small muted" style={{ margin: 0 }}>
              {ti("optionStoryHint")} {!storyAvailable && ti("optionStoryOff")}
            </p>
            <label className="row" style={{ alignItems: "center", gap: 8 }}>
              <input type="checkbox" name="requireConfirmation" defaultChecked={home.requireConfirmation} style={{ width: "auto" }} />
              {t("requireConfirmationOption")}
            </label>
            <p className="small muted" style={{ margin: 0 }}>{t("requireConfirmationHint")}</p>
            <div>
              <button className="btn secondary" type="submit">
                {ti("saveOptions")}
              </button>
            </div>
          </form>
        </section>
      )}

      {canWrite && telegramConfigured() && (
        <section className="card stack">
          <h2>{tt("groupTitle")}</h2>
          {home.telegramChatId ? (
            <>
              <p>{tt("groupLinked")}</p>
              <form action={disconnectGroupAction}>
                <input type="hidden" name="homeId" value={home.id} />
                <button className="btn secondary" type="submit">
                  {tt("disconnect")}
                </button>
              </form>
            </>
          ) : (
            <>
              <p className="muted">{tt("groupNotLinked")}</p>
              <form action={connectGroupAction}>
                <input type="hidden" name="homeId" value={home.id} />
                <button className="btn" type="submit">
                  {tt("connectGroup")}
                </button>
              </form>
              <p className="small muted">{tt("groupHint")}</p>
            </>
          )}
        </section>
      )}

      <section className="card" id="members">
        <h2>{tp("membersTitle")}</h2>
        <ul className="plain stack">
          {members.map((m) => (
            <li key={m.userId} className="row member-row">
              <span>
                <PlayerName name={m.name || tp("noName")} avatar={m.playerId ? byId.get(m.playerId)?.avatar : null} />{" "}
                <span className="badge">{m.role === "owner" ? t("owner") : t("member")}</span>{" "}
                {m.userId === userId && <span className="muted small">({tp("you")}) </span>}
                <span className="muted small">{tp("joined", { date: formatDate(m.joinedAt, locale) })}</span>
              </span>
              {isOwner && m.role === "member" && (
                <form action={removeMemberAction}>
                  <input type="hidden" name="homeId" value={home.id} />
                  <input type="hidden" name="userId" value={m.userId} />
                  <button className="btn small danger" type="submit">
                    {tp("remove")}
                  </button>
                </form>
              )}
            </li>
          ))}
        </ul>
        {isOwner && <p className="small muted">{tp("removeHint")}</p>}
      </section>

      {isOwner && (
        <section className="card stack" id="invites">
          <h2>{tp("invitesTitle")}</h2>
          {invites.length === 0 ? (
            <p className="muted">{tp("invitesNone")}</p>
          ) : (
            <ul className="plain stack">
              {invites.map((i) => (
                <li key={i.id} className="invite-row stack">
                  <div className="row member-row">
                    <span>
                      <strong>{i.playerId ? tp("inviteFor", { name: name.get(i.playerId) ?? "?" }) : tp("inviteAnyone")}</strong>{" "}
                      <span className="muted small">
                        {i.email && <>{tp("inviteSentTo", { email: i.email })} · </>}
                        {tp("inviteUses", { uses: num(i.uses), max: num(i.maxUses) })} ·{" "}
                        {tp("inviteExpires", { date: formatDate(i.expiresAt, locale, true) })}
                      </span>
                    </span>
                    <form action={revokeInviteAction}>
                      <input type="hidden" name="homeId" value={home.id} />
                      <input type="hidden" name="inviteId" value={i.id} />
                      <button className="btn small secondary" type="submit">
                        {tp("revoke")}
                      </button>
                    </form>
                  </div>
                  {i.url && i.qr ? (
                    <>
                      <div className="row invite-link">
                        <span className="mono small" dir="ltr">
                          {i.url}
                        </span>
                        <CopyButton text={i.url} label={tp("copyLink")} done={tp("copied")} />
                      </div>
                      <details>
                        <summary>{tp("inviteShowQr")}</summary>
                        {/* eslint-disable-next-line @next/next/no-img-element -- a data: URL drawn on the server */}
                        <img className="invite-qr" src={i.qr} width={260} height={260} alt={tp("inviteQrAlt")} />
                      </details>
                    </>
                  ) : (
                    <p className="small muted">{tp("inviteLegacy")}</p>
                  )}
                </li>
              ))}
            </ul>
          )}
          {canWrite && (
            <form action={createInviteAction} className="row">
              <input type="hidden" name="homeId" value={home.id} />
              <label>
                {tp("inviteForPlayer")}
                <select name="playerId" style={{ width: "auto" }}>
                  <option value="">{tp("inviteAnyone")}</option>
                  {active
                    .filter((p) => !p.userId)
                    .map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.displayName}
                      </option>
                    ))}
                </select>
              </label>
              <label>
                {tp("inviteMaxUses")}
                <select name="maxUses" style={{ width: "auto" }} defaultValue="1">
                  {[1, 5, 20].map((n) => (
                    <option key={n} value={n}>
                      {num(n)}
                    </option>
                  ))}
                </select>
              </label>
              <label style={{ flex: "1 1 220px" }}>
                {tp("inviteEmailLabel")}
                <input name="email" type="email" maxLength={254} dir="ltr" autoComplete="email" />
              </label>
              <button className="btn secondary" type="submit">
                {t("inviteCreate")}
              </button>
              <p className="small muted" style={{ margin: 0, flexBasis: "100%" }}>
                {tp("inviteEmailHint")}
              </p>
            </form>
          )}
        </section>
      )}

      {canWrite && active.length >= 2 && (
        <section className="card stack" id="merge">
          <h2>{tp("mergeTitle")}</h2>
          <p className="small muted">{tp("mergeHint")}</p>
          <form action={mergePlayersAction} className="row">
            <input type="hidden" name="homeId" value={home.id} />
            <label>
              {tp("mergeKeep")}
              <select name="keepId" required style={{ width: "auto" }}>
                {active.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.displayName}
                  </option>
                ))}
              </select>
            </label>
            <label>
              {tp("mergeDuplicate")}
              <select name="duplicateId" required style={{ width: "auto" }} defaultValue={active[1]!.id}>
                {active.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.displayName}
                  </option>
                ))}
              </select>
            </label>
            <button className="btn danger" type="submit">
              {tp("mergeButton")}
            </button>
          </form>
        </section>
      )}
    </>
  );
}
